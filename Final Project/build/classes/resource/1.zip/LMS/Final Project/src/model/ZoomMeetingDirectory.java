package model;

import java.util.List;

public class ZoomMeetingDirectory extends Directory<ZoomMeeting>{

    public ZoomMeetingDirectory() {
    }

    public ZoomMeetingDirectory(List<ZoomMeeting> list){
        super(list);
    }
}
